import React from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import {getData, formatData} from './app-data.service';
import _ from 'lodash';

 
class AppChart extends React.Component {
  _self= this;
  options = {
    chart: {
        plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie'
    },
    title: {
      text: 'My chart'
    },
    plotOptions: {
          pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              dataLabels: {
                  enabled: false,
                  format: '<b>{point.name}</b>: {point.percentage:.1f} %'
              },
              point: {
                  events: {
                      click: this.ChartClick.bind(this)
                  }
              }
          },

      },
    series: [
      {
          name: 'Applications',
          colorByPoint: true,
          data: []
      }
    ]
  };
  constructor(){
    super();
    this.state={
      chartOptions: this.options
    };
  }

  componentDidUpdate(prevProps){
    console.log('from DID Update', prevProps, this.props.list);
  //if(this.props.isDataLoaded){
    const list =this.props.list;
    if(list !== prevProps.list){
      
       const series= Object.keys(list).map(x=>{
          return {
            name: x,
            y: list[x].length
          }
        })
        
        
        console.log('from Component', series);
        this.setState({chartOptions: {
          ...this.state.chartOptions,
          ...{series:{ data: series}}
        } });
    }
//}
  }

  componentDidMount = () =>{

    console.log('did mount', this.props.list);
    if(this.props.list){
      const list =this.props.list;
       const series= Object.keys(list).map(x=>{
          return {
            name: x,
            y: list[x].length
          }
        })
        
        
        console.log('from Component', series);
        this.setState({chartOptions: {
          ...this.state.chartOptions,
          ...{series:{ data: series}}
        } });
    }

    /*
    getData().then(
      (res)=> {

       const list= formatData(res);
       const grouped =list && _.groupBy(list, car => car.price);
       console.log('grouped', grouped);
        const series= Object.keys(grouped).map(x=>{
          return {
            name: x,
            y: grouped[x].length
          }
        })
        
        
        console.log('from Component', series);
        this.setState({chartOptions: {
          ...this.state.chartOptions,
          ...{series:{ data: series}}
        } });
      }
    );
    */
  }

  ChartClick(event) {
    console.log('name', event.point.name);
    this.props.chartClick(event.point.name);
  };
   
  render(){
    {console.log(this.state.chartOptions)}
    return ( <HighchartsReact highcharts={Highcharts} options={this.state.chartOptions} />)
  }
}

export default AppChart;