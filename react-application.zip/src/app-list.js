import React from 'react';
import render from 'react-dom';

class AppList extends React.Component {
  constructor(props){
      super(props);
      this.onFilter= this.onFilter.bind(this);
      this.onSort= this.onSort.bind(this);
  }

  onFilter(evt){
    console.log('evt', evt.target.value);
    this.props.filterChange(evt.target.value);
  }

  onSort(evt) {
    console.log('sort', evt.target.value);
    this.props.onSorting(evt.target.value);
  }

    render(){
      return (
        <div>
          <div class="filter-section">
            <div>
              Filter: <input type="text" onChange={this.onFilter}/>
            </div>
            <div>
              Sort By: 
              <select onChange={this.onSort}>
                <option value="date">Date</option>
                <option value="price">Price</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>
          {this.props.list? this.props.list.map(item=>{
            return (
            <div class="app-box">
                <img src={item.image} />
                <div class="app-detail">
                  <span>{item.title}</span><br/>
                  <span>{item.category}</span><br/>
                  <span>{item.price}</span>
                </div>
            </div>
            )
          }): <h1>No data available</h1>}
        </div>
      );
    }
}

export default AppList;