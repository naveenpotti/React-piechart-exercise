export const getData= () => {
  return fetch('https://itunes.apple.com/us/rss/toppaidapplications/limit=100/json')
  .then(res => res.json());
}

export const formatData = (list)=> {
  console.log('result', list)
  if(list && list.feed && list.feed.entry){
    return list.feed.entry.map(item => {
      const images= item['im:image'];
      console.log(images);
      const obj= {
        id: item['id'].label,
        name: item['im:name'].label,
        title: item['title'].label,
        price: item['im:price'].label,
        releaseDate: item['im:releaseDate'].label,
        category: item['category'].attributes.term,
        image: images[0].label
      }
      return obj;
    });
  }
  return [];
}