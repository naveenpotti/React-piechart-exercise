import React from "react";
import { render} from 'react-dom';
import "./style.css";
import AppChart from './app-chart'
import AppList from './app-list';
import {getData, formatData} from './app-data.service';
import _ from 'lodash';


class App extends React.Component{
  constructor(props) {
    super(props);
    this.state= {
      list: [],
      selectedOption: null,
      selectedList: [],
      isDataLoaded: false,
      sortedList: []
    }
    this.onFilterChange= this.onFilterChange.bind(this);
  }  

componentDidMount(){
  getData().then(
      (res)=> {
       const list= formatData(res);
       const groupedList =list && _.groupBy(list, x => x.price);
       this.setState({list: groupedList, isDataLoaded: true})
      }
    );
}

  selectedApplication=(name)=>{
    console.log('from App', name);
    this.setState({selectedOption: name, selectedList: this.state.list[name], sortedList: this.state.list[name]})
  }

  onFilterChange = (value)=> {
    console.log('filter', value)
    if(value){
      const filterdList= _.filter(this.state.selectedList, function(o) { 
        console.log('o', o)
          return o.title.toLowerCase().indexOf(value)>-1; 
        });
        this.setState({sortedList: filterdList});
      }
  }

  onSorting = (value)=> {
    console.log('filter', value)
    if(value){
      const filterdList= _.sortBy(this.state.selectedList, [value]);
        this.setState({sortedList: filterdList});
      }
  }

  render(){
      return this.state.list ?(
        <div>
          <AppChart isDataLoaded={this.state.isDataLoaded} list={this.state.list} chartClick={this.selectedApplication}/>
          <AppList list= {this.state.sortedList} filterChange={this.onFilterChange} onSorting={this.onSorting} />
        </div>
      ): null;
  }
}

export default App;
